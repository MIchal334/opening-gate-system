#Outdoor camera config
OUTDOOR_CAMERA_USER = 'admin'
OUTDOOR_CAMERA_PASSWORD = 'Admin1234'
OUTDOOR_CAMERA_IP = '192.168.0.216/11'

#Indoor camera config
INDOOR_CAMERA_USER = 'admin'
INDOOR_CAMERA_PASSWORD = 'Admin1234'
INDOOR_CAMERA_IP = '192.168.0.216/11'


#car regognize cnn config
CAR_REGOGNIZE_CNN_MODEL_PATH = '/home/michalm/Desktop/POC_GATE/sieci/car_recognize_model.keras'
CAR_REGOGNIZE_CNN_FRAME_X_SIZE = 64
CAR_REGOGNIZE_CNN_FRAME_Y_SIZE = 64


#car bb cnn config
CAR_BB_CNN_MODEL_PATH = '/home/michalm/Desktop/POC_GATE/sieci/car_boxes_model'
CAR_BB_CNN_FRAME_X_SIZE = 297
CAR_BB_CNN_FRAME_Y_SIZE = 166


#link for tests video
INDOR_TEST_LINK  = '/home/michalm/Desktop/POC_GATE/wyjazd.mp4'